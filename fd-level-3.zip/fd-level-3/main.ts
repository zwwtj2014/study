import { Train } from "./train";

window["train"] = new Train();
